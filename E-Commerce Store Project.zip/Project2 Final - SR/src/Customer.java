public class Customer {
    private String name;
    private String email;
    private Long phone; //Using Long here after discussion with TA Saivinay, it takes phone numbers effectively

    //Setting constructor
    public Customer (String name) {
        this.name = "guest";
        this.email = "0";
        this.phone = 0L;
    }

    //Get methods
    public String getCustomer_name(){
        return name;
    }

    public String getCustomer_email() {
        return email;
    }

    public Long getCustomer_phone() {
        return phone;
    }

    //Set methods
    public void setCustomer_name(String name) {
        this.name = name;
    }

    public void setCustomer_email(String email) {
        this.email = email;
    }

    public void setCustomer_phone(Long phone) {
        this.phone = phone;
    }
}
