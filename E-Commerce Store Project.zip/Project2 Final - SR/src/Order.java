public class Order {
    public int id;
    private double total;

    //Setting constructor
    public Order (int id, double total) {
        this.id = id;
        this.total = total;
    }

    //Get method
    public double getOrder_total() {
        return total;
    }

    //Set method
    public void setOrder_total(double total) {
        this.total = total;
    }
}
